import numpy as np
from sklearn.svm import LinearSVC
from sklearn import linear_model
from sklearn import svm
import time
import math

numSamples1 = 1000 #Training Samples
numSamples2 = 500 #Testing Samples
numFeatures = 47236 

fileName = "Train_rcv"
f = open(fileName,'r')
linesList = f.readlines()
f.close()
linesList = linesList[:1000]
Ymat = np.zeros((numSamples1,1))
Xmat = np.zeros((numSamples1,numFeatures))


count = 0

for i in (linesList):

    templst = i.split(" ")
    if (templst[0] == "1"):
        Ymat[(count,0)] = 1
    else:
        Ymat[(count,0)] = 0

    templst = templst[1:-1]
    for x in templst:
        lst = x.split(":")
        p = int(lst[0])-1
        q = float(lst[1])
        Xmat[(count,p)]= q
    
    count = count+1

assert(count == numSamples1)





X = np.zeros((numSamples2,numFeatures))
Y = np.zeros((numSamples2,1))

fileName = "Test_rcv"
f = open(fileName,'r')
linesList = f.readlines()
f.close()
linesList = linesList[:500]

count = 0

for i in (linesList):

    templst = i.split(" ")
    if (templst[0] == "1"):
        Y[(count,0)] = 1
    else:
        Y[(count,0)] = 0

    templst = templst[1:-1]
    for x in templst:
        lst = x.split(":")
        p = int(lst[0])-1
        q = float(lst[1])
        X[(count,p)]= q
    
    count = count+1

assert(count == numSamples2)


max_acc = 0
trainTime = 0
testTime = 0

for i in [0.001,0.01,0.1,0.5,0.75,0.89]:
    for j in [0.0001,0.001,0.01,0.1,0.2,0.4,'auto']:
    	print(i,j)
        clf = svm.NuSVC(nu = i,kernel='rbf',gamma = j)
        t1 = time.time()
        clf = clf.fit(Xmat,Ymat)
        t2 = time.time()
        perf =  (clf.score(X,Y))
        t3 = time.time()
        if perf > max_acc:
            trainTime = t2-t1
            testTime = t3-t2
            max_acc = perf
print("NSVM - rbf - start")
print(max_acc)
print(trainTime)
print(testTime)
print("NSVM -rbf - end")

max_acc = 0
trainTime = 0
testTime = 0

## Try with degree = 4,5,6
for c in [0.001,0.01,0.1,1,10,100]:
    for i in [0.001,0.1,0.5,0.85]:
        for j in [0.0001,0.001,0.1,0.2,0.4,'auto']:
            clf = svm.NuSVC(nu = i,kernel='poly',degree = 3,gamma= j, coef0 = c)
            t1 = time.time()
            clf = clf.fit(Xmat,Ymat)
            t2 = time.time()
            perf =  (clf.score(X,Y))
            t3 = time.time()
            if perf > max_acc:
                trainTime = t2-t1
                testTime = t3-t2
                max_acc = perf
print("NSVM - poly - start")
print(max_acc)
print(trainTime)
print(testTime)
print("NSVM - poly - end")
