import numpy as np
import time
import math
import matplotlib.pyplot as plt

numSamples1 = 3000 #Training Samples
numSamples2 = 1000 #Testing Samples
numFeatures = 47236 

fileName = "Train_rcv"
f = open(fileName,'r')
linesList = f.readlines()
f.close()

Ymat = np.zeros((numSamples1,1))
Xmat = []


count = 0

for i in (linesList):

    templst = i.split(" ")
    if (templst[0] == "1"):
        Ymat[(count,0)] = 1
    else:
        Ymat[(count,0)] = 0

    templst = templst[1:-1]
    for x in templst:
        lst = x.split(":")
        p = int(lst[0])-1
        q = float(lst[1])
        Xmat = Xmat+[q]
    
    count = count+1

assert(count == numSamples1)

plt.scatter(x,y)
plt.show()
