import numpy as np
from sklearn.svm import LinearSVC
from sklearn import linear_model
from sklearn import svm
import time
import math

numSamples1 = 3000 #Training Samples
numSamples2 = 1000 #Testing Samples
numFeatures = 47236 

fileName = "Train_rcv"
f = open(fileName,'r')
linesList = f.readlines()
f.close()

Ymat = np.zeros((numSamples1,1))
Xmat = np.zeros((numSamples1,numFeatures))


count = 0

for i in (linesList):

    templst = i.split(" ")
    if (templst[0] == "1"):
        Ymat[(count,0)] = 1
    else:
        Ymat[(count,0)] = 0

    templst = templst[1:-1]
    for x in templst:
        lst = x.split(":")
        p = int(lst[0])-1
        q = float(lst[1])
        Xmat[(count,p)]= q
    
    count = count+1

assert(count == numSamples1)





X = np.zeros((numSamples2,numFeatures))
Y = np.zeros((numSamples2,1))

fileName = "Test_rcv"
f = open(fileName,'r')
linesList = f.readlines()
f.close()

count = 0

for i in (linesList):

    templst = i.split(" ")
    if (templst[0] == "1"):
        Y[(count,0)] = 1
    else:
        Y[(count,0)] = 0

    templst = templst[1:-1]
    for x in templst:
        lst = x.split(":")
        p = int(lst[0])-1
        q = float(lst[1])
        X[(count,p)]= q
    
    count = count+1

assert(count == numSamples2)




max_acc = 0
trainTime = 0
testTime = 0

    
for i in [0.001, 0.01,0.1,0.5,1,5,10,20,100]:
    clf = LinearSVC(penalty='l2', loss='squared_hinge', dual=False, tol=0.0001, C=i)
    t1 = time.time()
    clf = clf.fit(Xmat,Ymat)
    t2 = time.time()
    perf =  (clf.score(X,Y))
    t3 = time.time()
    if perf > max_acc:
        trainTime = t2-t1
        testTime = t3-t2
        max_acc = perf
        
print("Linear SVM - start")
print(max_acc)
print(trainTime)
print(testTime)
print("Linear SVM - end")



max_acc = 0
trainTime = 0
testTime = 0

for i in [0.001, 0.01,0.1,0.5,1,5,10,20,100]:
    clf = linear_model.LogisticRegression(C=i)
    t1 = time.time()
    clf = clf.fit(Xmat,Ymat)
    t2 = time.time()
    perf =  (clf.score(X,Y))
    t3 = time.time()
    if perf > max_acc:
        trainTime = t2-t1
        testTime = t3-t2
        max_acc = perf
    
print(max_acc)
print(trainTime)
print(testTime)

        
print("Logistic Regression - start")
print(max_acc)
print(trainTime)
print(testTime)
print("Logistic Regression - end")












#Logistic regression
clf = sklearn.linear_model.LogisticRegression(penalty='l2', dual=False, tol=0.0001, C=1.0, fit_intercept=True, intercept_scaling=1,solver='sag', max_iter=100, warm_start=False)
#solver='liblinear', C, warm_start = True

#non linear SVM
clf2 = sklearn.svm.NuSVC(nu=0.5, kernel='rbf', degree=3, gamma='auto', coef0=0.0, shrinking=True, tol=0.001)
#nu , gamma can be challanged,kernel try with rbf and poly and sigmoid /poly - degree  coeff = float soignificant in poly and sigmoid



#linear SVM

clf3 = LinearSVC(penalty='l2', loss='squared_hinge', dual=False, tol=0.0001, C=i)


# 5000 samples good

