import numpy as np
from sklearn.feature_extraction import FeatureHasher
from sklearn import linear_model
import time

numSamples1 = 3000
numSamples2 = 1000
numFeatures = 54877

fileName = "Train_fads"
f = open(fileName,'r')
linesList = f.readlines()
f.close()

Ymat = np.zeros((numSamples1,1))

count = 0
D = []
for i in (linesList):
    dic = {}
    templst = i.split(" ")
    
    if (templst[0] == "1"):
        Ymat[(count,0)] = 1
    else:
        Ymat[(count,0)] = 0

    templst = templst[1:-1]
    for x in templst:
        lst = x.split(":")
        p = lst[0]
        q = float(lst[1])
        dic[p] = q
        
    D.append(dic)
    count = count+1

assert(len(D) == count and len(D) == numSamples1)

redDim = 40000
h = FeatureHasher(n_features = redDim)
Xmat = h.transform(D)



fileName = "Test_fads"
f = open(fileName,'r')
linesList = f.readlines()
f.close()

Y = np.zeros((numSamples2,1))

count = 0
D = []
for i in (linesList):
    dic = {}
    templst = i.split(" ")
    
    if (templst[0] == "1"):
        Y[(count,0)] = 1
    else:
        Y[(count,0)] = 0

    templst = templst[1:-1]
    for x in templst:
        lst = x.split(":")
        p = lst[0]
        q = float(lst[1])
        dic[p] = q
        
    D.append(dic)
    count = count+1

assert(len(D) == count and len(D) == numSamples2)

linesList =[]
X = h.transform(D)

max_acc = 0
trainTime = 0
testTime = 0

for i in [0.001, 0.01,0.1,0.5,1,5,10,20,100]:
    clf = linear_model.LogisticRegression(C=i)
    t1 = time.time()
    clf = clf.fit(Xmat,Ymat)
    t2 = time.time()
    perf =  (clf.score(X,Y))
    t3 = time.time()
    if perf > max_acc:
        trainTime = t2-t1
        testTime = t3-t2
        max_acc = perf
    
print(max_acc)
print(trainTime)
print(testTime)






