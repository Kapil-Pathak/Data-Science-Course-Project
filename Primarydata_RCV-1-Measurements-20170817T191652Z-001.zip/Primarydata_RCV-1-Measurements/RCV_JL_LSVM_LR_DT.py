import numpy as np
from sklearn import linear_model
from sklearn import tree
from sklearn.svm import LinearSVC
import math
import time


numSamples1 = 3000
numSamples2 = 1000
numFeatures = 47236

fileName = "Train_rcv"
f = open(fileName,'r')
linesList = f.readlines()
f.close()

Xmat = np.zeros((numSamples1,numFeatures))
Ymat = np.zeros((numSamples1,1))

count = 0

for i in (linesList):
    
    templst = i.split(" ")
    
    if (templst[0] == "1"):
        Ymat[(count,0)] = 1
    else:
        Ymat[(count,0)] = 0

    templst = templst[1:-1]
    for x in templst:
        lst = x.split(":")
        p = int(lst[0])
        Xmat[(count,p)] = float(lst[1])
        
    count = count+1

assert(Xmat.shape[0] == numSamples1)






redDim = 10000	## Parameter to be changed
Xred = np.zeros((numSamples1,0))

#JL
mu=0
sigma=1

k = redDim
#k=math.floor(numFeatures*i/5)
temp = np.zeros((numFeatures,100))


for i in range(0,(redDim/100)):
    temp = (np.random.normal(mu,sigma,size=(numFeatures,100)))/math.sqrt(k)
    Xred = np.concatenate((Xred,(np.dot(Xmat,temp))),axis=1)




Xmat =[]

fileName = "Test_rcv"
f = open(fileName,'r')
linesList = f.readlines()
f.close()

Xtest = np.zeros((numSamples2,numFeatures))
Y = np.zeros((numSamples2,1))

count = 0

for i in (linesList):
    templst = i.split(" ")
    
    if (templst[0] == "1"):
        Y[(count,0)] = 1
    else:
        Y[(count,0)] = 0

    templst = templst[1:-1]
    for x in templst:
        lst = x.split(":")
        p = int(lst[0])-1
        Xtest[(count,p)] = float(lst[1])
        
    count = count+1

assert(Xtest.shape[0] == numSamples2)

X = np.zeros((numSamples2,0))
temp = np.zeros((numFeatures,100))


for i in range(0,(redDim/100)):
    temp = (np.random.normal(mu,sigma,size=(numFeatures,100)))/math.sqrt(k)
    X = np.concatenate((X,(np.dot(Xtest,temp))),axis=1)

max_acc = 0
trainTime = 0
testTime = 0

for i in [0.001, 0.01,0.1,0.5,1,5,10,20,100]:
    clf = linear_model.LogisticRegression(C=i)
    t1 = time.time()
    clf = clf.fit(Xred,Ymat)
    t2 = time.time()
    perf =  (clf.score(X,Y))
    t3 = time.time()
    if perf > max_acc:
        trainTime = t2-t1
        testTime = t3-t2
        max_acc = perf


print('LR')
print(max_acc)
print(trainTime)
print(testTime)

max_acc = 0
trainTime = 0
testTime = 0

clf = tree.DecisionTreeClassifier()
t1 = time.time()
clf = clf.fit(Xred,Ymat)
t2 = time.time()
perf =  (clf.score(X,Y))
t3 = time.time()

trainTime = t2-t1
testTime = t3-t2
#max_acc = perf

print('DT')
print(perf)
print(trainTime)
print(testTime)

max_acc = 0
trainTime = 0
testTime = 0

for i in [0.001, 0.01,0.1,0.5,1,5,10,20,100]:
    clf = LinearSVC(penalty='l2', loss='squared_hinge', dual=False, tol=0.0001, C=i)
    t1 = time.time()
    clf = clf.fit(Xred,Ymat)
    t2 = time.time()
    perf =  (clf.score(X,Y))
    t3 = time.time()
    if perf > max_acc:
        trainTime = t2-t1
        testTime = t3-t2
        max_acc = perf


print('LSVM')
print(max_acc)
print(trainTime)
print(testTime)


