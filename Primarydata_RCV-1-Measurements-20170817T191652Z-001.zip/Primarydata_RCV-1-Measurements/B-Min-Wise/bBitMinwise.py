import numpy as np
import math
from sklearn.svm import LinearSVC
from sklearn import linear_model
from sklearn import svm
import time

def Exp(Xmat,b,numCol):
    m = pow(2,b)
    X = np.zeros((Xmat.shape[0],numCol*m),dtype = float)
    for i in range(Xmat.shape[0]):
        for j in range(numCol):
            tem = Xmat[(i,j)]
            t = int(tem%m)
            X[(i,t+j*m)] = 1

    return X
    
    

Xmat = np.zeros((1000,50))
Ymat = np.zeros((1000,1))






for i in range(1,11):
    fname= 'test'+str(i)+'.txt'
    temp = np.loadtxt(fname)
    Xmat[(i-1)*100:(i*100)][:] = temp

print(Xmat.shape)

X = Exp(Xmat,8,20)

print(X.shape)

fileName = "Train_rcv"
f = open(fileName,'r')
linesList = f.readlines()
f.close()

linesList = linesList[:1000]
count = 0

for i in (linesList):

    templst = i.split(" ")
    if (templst[0] == "1"):
        Ymat[(count,0)] = 1
    else:
        Ymat[(count,0)] = 0
    
    count = count+1

linesList = []

print(count)
print(type(X))

max_acc = 0
trainTime = 0
testTime = 0

    
for i in [0.001, 0.01,0.1,0.5,1,5,10,20,100]:
    clf = LinearSVC(penalty='l2', loss='squared_hinge', dual=False, tol=0.0001, C=i)
    t1 = time.time()
    clf = clf.fit(X[:800][:],Ymat[:800][:])
    t2 = time.time()
    perf =  (clf.score(X[800:1000][:],Ymat[800:1000][:]))
    t3 = time.time()
    if perf > max_acc:
        trainTime = t2-t1
        testTime = t3-t2
        max_acc = perf
        
print("Linear SVM - start")
print(max_acc)
print(trainTime)
print(testTime)
print("Linear SVM - end")



max_acc = 0
trainTime = 0
testTime = 0

for i in [0.001, 0.01,0.1,0.5,1,5,10,20,100]:
    clf = linear_model.LogisticRegression(C=i)
    t1 = time.time()
    clf = clf.fit(X[:800][:],Ymat[:800][:])
    t2 = time.time()
    perf =  (clf.score(X[800:1000][:],Ymat[800:1000][:]))
    t3 = time.time()
    if perf > max_acc:
        trainTime = t2-t1
        testTime = t3-t2
        max_acc = perf
    
print(max_acc)
print(trainTime)
print(testTime)

        
print("Logistic Regression - start")
print(max_acc)
print(trainTime)
print(testTime)
print("Logistic Regression - end")



    
